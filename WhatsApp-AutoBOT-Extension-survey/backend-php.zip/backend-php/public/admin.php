<?php
declare(strict_types=1);

require_once __DIR__ . '/../src/bootstrap.php';

session_start();

$services = app_services();
$creds = $services->getAdminCredentials();

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'logout') {
    $_SESSION = [];
    session_destroy();
    header('Location: admin.php');
    exit;
}

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    $loginError = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'login') {
        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');

        if (hash_equals($creds['username'], $username) && hash_equals($creds['password'], $password)) {
            $_SESSION['admin_logged_in'] = true;
            header('Location: admin.php');
            exit;
        }

        $loginError = 'Invalid username or password.';
    }

    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartDM Admin Login</title>
    <style>
        body { font-family: Arial, sans-serif; background: #0f172a; color: #e2e8f0; margin: 0; }
        .wrap { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .card { width: 100%; max-width: 420px; background: #111827; border: 1px solid #1f2937; border-radius: 14px; padding: 24px; }
        h1 { margin-top: 0; font-size: 22px; }
        label { display: block; margin-bottom: 6px; color: #cbd5e1; }
        input { width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #334155; background: #0b1220; color: #e2e8f0; margin-bottom: 14px; }
        button { width: 100%; padding: 11px; border: 0; border-radius: 8px; background: #22c55e; color: #052e16; font-weight: bold; cursor: pointer; }
        .error { background: #7f1d1d; color: #fecaca; border: 1px solid #991b1b; padding: 10px; border-radius: 8px; margin-bottom: 14px; }
        .hint { margin-top: 12px; font-size: 12px; color: #94a3b8; }
    </style>
</head>
<body>
<div class="wrap">
    <div class="card">
        <h1>SmartDM Admin</h1>
        <?php if ($loginError !== ''): ?>
            <div class="error"><?= e($loginError) ?></div>
        <?php endif; ?>
        <form method="post">
            <input type="hidden" name="action" value="login">
            <label for="username">Username</label>
            <input id="username" name="username" type="text" required>

            <label for="password">Password</label>
            <input id="password" name="password" type="password" required>

            <button type="submit">Sign In</button>
        </form>
        <div class="hint">Default credentials come from .env (`ADMIN_USERNAME` / `ADMIN_PASSWORD`).</div>
    </div>
</div>
</body>
</html>
<?php
    exit;
}

$flash = '';
$flashType = 'ok';
$tokenResult = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? '');

    try {
        if ($action === 'create_user_workspace') {
            $result = $services->adminCreateUserAndWorkspace([
                'email' => (string) ($_POST['email'] ?? ''),
                'fullName' => (string) ($_POST['full_name'] ?? ''),
                'password' => (string) ($_POST['password'] ?? ''),
                'workspaceName' => (string) ($_POST['workspace_name'] ?? ''),
                'whatsappPhone' => (string) ($_POST['whatsapp_phone'] ?? ''),
                'planName' => (string) ($_POST['plan_name'] ?? 'Basic'),
                'messagesLimit' => (string) ($_POST['messages_limit'] ?? '100'),
                'aiRepliesLimit' => (string) ($_POST['ai_replies_limit'] ?? '50'),
            ]);

            $flash = 'User/workspace created successfully for ' . ($result['user']['email'] ?? 'unknown');
            $flashType = 'ok';
        } elseif ($action === 'issue_tokens') {
            $tokenResult = $services->adminIssueTokens(
                (string) ($_POST['user_id'] ?? ''),
                (string) ($_POST['workspace_id'] ?? '')
            );
            $flash = 'Tokens issued successfully.';
            $flashType = 'ok';
        }
    } catch (Throwable $e) {
        $flash = $e->getMessage();
        $flashType = 'err';
    }
}

$snapshot = $services->getAdminSnapshot();
$users = $snapshot['users'];
$workspaces = $snapshot['workspaces'];
$usageTodayMap = $snapshot['usageTodayMap'];
$today = $snapshot['today'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartDM Admin Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f8fafc; color: #0f172a; margin: 0; }
        .top { background: #0f172a; color: #e2e8f0; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center; }
        .top h1 { margin: 0; font-size: 20px; }
        .container { padding: 18px; max-width: 1240px; margin: 0 auto; }
        .row { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 16px; margin-bottom: 16px; }
        .card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 14px; }
        .card h2 { margin: 0 0 12px; font-size: 18px; }
        .field { display: grid; gap: 6px; margin-bottom: 10px; }
        .field input, .field select { padding: 9px; border-radius: 8px; border: 1px solid #cbd5e1; }
        .btn { padding: 9px 12px; border-radius: 8px; border: 0; cursor: pointer; font-weight: 600; }
        .btn-primary { background: #2563eb; color: #ffffff; }
        .btn-danger { background: #ef4444; color: #ffffff; }
        .flash { padding: 10px; border-radius: 8px; margin-bottom: 14px; }
        .flash.ok { background: #dcfce7; border: 1px solid #86efac; color: #14532d; }
        .flash.err { background: #fee2e2; border: 1px solid #fca5a5; color: #7f1d1d; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th, td { border-bottom: 1px solid #e2e8f0; text-align: left; padding: 8px; vertical-align: top; }
        th { background: #f1f5f9; }
        code { background: #f1f5f9; padding: 2px 5px; border-radius: 4px; }
        .token-box { background: #0f172a; color: #e2e8f0; border-radius: 8px; padding: 10px; font-size: 12px; word-break: break-all; }
    </style>
</head>
<body>
<div class="top">
    <h1>SmartDM PHP Backend Admin</h1>
    <form method="post" style="margin:0;">
        <input type="hidden" name="action" value="logout">
        <button class="btn btn-danger" type="submit">Logout</button>
    </form>
</div>

<div class="container">
    <?php if ($flash !== ''): ?>
        <div class="flash <?= e($flashType) ?>"><?= e($flash) ?></div>
    <?php endif; ?>

    <div class="row">
        <div class="card">
            <h2>Create User + Workspace</h2>
            <form method="post">
                <input type="hidden" name="action" value="create_user_workspace">

                <div class="field"><label>Email</label><input type="email" name="email" required></div>
                <div class="field"><label>Full Name</label><input type="text" name="full_name" required></div>
                <div class="field"><label>Password (new user)</label><input type="text" name="password" placeholder="Min 8 chars"></div>
                <div class="field"><label>Workspace Name</label><input type="text" name="workspace_name" required></div>
                <div class="field"><label>WhatsApp Phone</label><input type="text" name="whatsapp_phone" placeholder="+923001234567"></div>
                <div class="field"><label>Plan Name</label><input type="text" name="plan_name" value="Basic"></div>
                <div class="field"><label>Messages / Day</label><input type="number" name="messages_limit" value="100"></div>
                <div class="field"><label>AI Replies / Day (-1 = unlimited)</label><input type="number" name="ai_replies_limit" value="50"></div>

                <button class="btn btn-primary" type="submit">Create</button>
            </form>
        </div>

        <div class="card">
            <h2>Issue Tokens</h2>
            <form method="post">
                <input type="hidden" name="action" value="issue_tokens">
                <div class="field"><label>User ID</label><input type="text" name="user_id" required></div>
                <div class="field"><label>Workspace ID</label><input type="text" name="workspace_id" required></div>
                <button class="btn btn-primary" type="submit">Generate Access + Refresh</button>
            </form>

            <?php if (is_array($tokenResult)): ?>
                <h3>Generated Tokens</h3>
                <div class="token-box"><strong>Access Token:</strong><br><?= e((string) ($tokenResult['tokens']['accessToken'] ?? '')) ?></div>
                <div style="height:8px"></div>
                <div class="token-box"><strong>Refresh Token:</strong><br><?= e((string) ($tokenResult['tokens']['refreshToken'] ?? '')) ?></div>
            <?php endif; ?>
        </div>
    </div>

    <div class="card" style="margin-bottom:16px;">
        <h2>Users</h2>
        <table>
            <thead>
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Name</th>
                <th>Created</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $u): ?>
                <tr>
                    <td><code><?= e((string) ($u['id'] ?? '')) ?></code></td>
                    <td><?= e((string) ($u['email'] ?? '')) ?></td>
                    <td><?= e((string) ($u['full_name'] ?? '')) ?></td>
                    <td><?= e((string) ($u['created_at'] ?? '')) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card">
        <h2>Workspaces (Usage Today: <?= e((string) $today) ?>)</h2>
        <table>
            <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>WhatsApp Phone</th>
                <th>Plan</th>
                <th>Msgs/Day</th>
                <th>AI/Day</th>
                <th>Used Msgs</th>
                <th>Used AI</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($workspaces as $w): ?>
                <?php $usage = $usageTodayMap[(string) ($w['id'] ?? '')] ?? ['messagesSent' => 0, 'aiReplies' => 0]; ?>
                <tr>
                    <td><code><?= e((string) ($w['id'] ?? '')) ?></code></td>
                    <td><?= e((string) ($w['name'] ?? '')) ?></td>
                    <td><?= e((string) ($w['whatsapp_phone'] ?? '')) ?></td>
                    <td><?= e((string) ($w['plan_name'] ?? 'Basic')) ?></td>
                    <td><?= e((string) ($w['plan_messages_per_day'] ?? '0')) ?></td>
                    <td><?= e((string) ($w['plan_ai_replies_per_day'] ?? '0')) ?></td>
                    <td><?= e((string) ($usage['messagesSent'] ?? 0)) ?></td>
                    <td><?= e((string) ($usage['aiReplies'] ?? 0)) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
